package com.mohammed.ai.study

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val cameraRequest = 100
    private val prefs by lazy { getSharedPreferences("study", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var dark = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = prefs.getBoolean("dark", false)
        showHome()
    }

    private fun baseRoot(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textDirection = View.TEXT_DIRECTION_RTL
            setBackgroundColor(if (dark) Color.rgb(10, 22, 42) else Color.rgb(247, 249, 253))
        }
        return root
    }

    private fun title(text: String, size: Float = 27f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        setTextColor(if (dark) Color.WHITE else Color.rgb(15, 35, 65))
        gravity = Gravity.RIGHT
        setPadding(4, 8, 4, 12)
    }

    private fun subtitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(if (dark) Color.LTGRAY else Color.rgb(75, 90, 110))
        gravity = Gravity.RIGHT
        setPadding(4, 0, 4, 14)
    }

    private fun card(label: String, desc: String, emoji: String, action: () -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(18, 14, 18, 14)
            background = rounded(if (dark) Color.rgb(22, 42, 72) else Color.WHITE, 22)
            elevation = 3f
            isClickable = true
            setOnClickListener { action() }
        }
        val top = TextView(this).apply {
            text = "$emoji  $label"
            textSize = 18f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(if (dark) Color.WHITE else Color.rgb(20, 45, 85))
            gravity = Gravity.RIGHT
        }
        val d = TextView(this).apply {
            text = desc
            textSize = 13f
            setTextColor(if (dark) Color.LTGRAY else Color.rgb(95, 105, 120))
            gravity = Gravity.RIGHT
            setPadding(0, 7, 0, 0)
        }
        box.addView(top); box.addView(d)
        val lp = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, 12)
        root.addView(box, lp)
        return box
    }

    private fun rounded(color: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        setStroke(1, if (dark) Color.rgb(45, 70, 105) else Color.rgb(225, 230, 238))
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, 52); lp.setMargins(0, 5, 0, 5)
        root.addView(this, lp)
    }

    private fun scroll(content: LinearLayout): ScrollView = ScrollView(this).apply {
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        addView(content)
    }

    private fun showHome() {
        baseRoot()
        root.addView(title("محمد AI Study", 31f))
        root.addView(subtitle("مساعدك الذكي في الدراسة • إنتاج: محمد زهير"))
        val welcome = TextView(this).apply {
            text = "ابدأ بخطوة صغيرة اليوم، وخلي دراستك أذكى وأسهل."
            textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setPadding(18, 18, 18, 18)
            background = rounded(Color.rgb(19, 92, 190), 24)
        }
        root.addView(welcome, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0,0,0,16) })
        card("تلخيص الدروس", "اكتب الدرس واحصل على ملخص مرتب وواضح.", "📚") { summarize() }
        card("تصوير الدرس", "التقط صورة للدرس لقراءته وتجهيزه للتلخيص.", "📷") { openCamera() }
        card("خطة الدراسة", "نظم وقتك ومهامك اليومية.", "📅") { studyPlan() }
        card("ملاحظاتي", "احفظ أفكارك وملاحظاتك داخل التطبيق.", "📝") { notes() }
        card("موادي الدراسية", "رتب المواد التي تدرسها في مكان واحد.", "📖") { subjects() }
        card("اختبر نفسك", "اختبار قصير لتراجع فهمك.", "✅") { quiz() }
        card("البحث", "ابحث داخل أدوات التطبيق بسرعة.", "🔎") { search() }
        card("الإعدادات", "الوضع الليلي ومعلومات التطبيق.", "⚙️") { settings() }
        setContentView(scroll(root))
    }

    private fun summarize() {
        baseRoot(); root.addView(title("تلخيص الدروس")); root.addView(subtitle("ضع نص الدرس هنا، وسيتم ترتيب أهم الأفكار لك."))
        val input = EditText(this).apply { hint = "اكتب أو الصق نص الدرس..."; minLines = 8; gravity = Gravity.TOP or Gravity.RIGHT; setPadding(18,18,18,18); background = rounded(if (dark) Color.rgb(22,42,72) else Color.WHITE, 20) }
        root.addView(input, LinearLayout.LayoutParams(-1, 230))
        button("✨ إنشاء ملخص") { 
            val text = input.text.toString().trim()
            if (text.isEmpty()) toast("اكتب نص الدرس أولاً.") else showSummary(text)
        }
        button("← الرئيسية") { showHome() }
        setContentView(scroll(root))
    }

    private fun showSummary(text: String) {
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        val short = if (words.size > 90) words.take(90).joinToString(" ") + "…" else text
        AlertDialog.Builder(this).setTitle("ملخص الدرس").setMessage("أهم ما ورد في النص:\n\n$short\n\nملاحظة: هذه النسخة المحلية ترتب النص وتختصره مبدئيًا. ربط محرك ذكاء اصطناعي خارجي يحتاج خدمة ومفتاح API آمن.").setPositiveButton("حسنًا", null).show()
    }

    private fun notes() {
        baseRoot(); root.addView(title("ملاحظاتي")); root.addView(subtitle("ملاحظاتك محفوظة على جهازك."))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val saved = prefs.getString("notes", "")!!.split("\\n---\\n").filter { it.isNotBlank() }
        if (saved.isEmpty()) list.addView(subtitle("لا توجد ملاحظات بعد.")) else saved.forEachIndexed { i, n ->
            val t = TextView(this).apply { text = "${i+1}. $n"; textSize=16f; setTextColor(if(dark)Color.WHITE else Color.DKGRAY); setPadding(14,14,14,14); background=rounded(if(dark)Color.rgb(22,42,72) else Color.WHITE,18) }
            list.addView(t, LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,8)})
        }
        root.addView(list)
        button("＋ إضافة ملاحظة") { addNote() }
        button("← الرئيسية") { showHome() }
        setContentView(scroll(root))
    }

    private fun addNote() {
        val input = EditText(this).apply { hint="اكتب ملاحظتك..."; minLines=4; gravity=Gravity.TOP or Gravity.RIGHT }
        AlertDialog.Builder(this).setTitle("ملاحظة جديدة").setView(input).setNegativeButton("إلغاء",null).setPositiveButton("حفظ") { _,_ ->
            val old = prefs.getString("notes", "") ?: ""
            val newText = input.text.toString().trim(); if(newText.isNotEmpty()) prefs.edit().putString("notes", if(old.isBlank()) newText else "$old\\n---\\n$newText").apply()
            notes()
        }.show()
    }

    private fun subjects() {
        baseRoot(); root.addView(title("موادي الدراسية")); root.addView(subtitle("قائمة بسيطة لمتابعة موادك."))
        val defaults = listOf("الرياضيات","العلوم","اللغة العربية","اللغة الإنجليزية","الاجتماعيات","التربية الإسلامية")
        val extra = prefs.getStringSet("subjects", emptySet()) ?: emptySet()
        (defaults + extra).distinct().forEach { s ->
            val tv=TextView(this).apply{text="📖  $s";textSize=17f;setTextColor(if(dark)Color.WHITE else Color.rgb(25,45,70));setPadding(18,16,18,16);background=rounded(if(dark)Color.rgb(22,42,72) else Color.WHITE,18)}
            root.addView(tv,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,9)})
        }
        button("＋ إضافة مادة") { addSubject() }; button("← الرئيسية"){showHome()}; setContentView(scroll(root))
    }

    private fun addSubject(){
        val input=EditText(this).apply{hint="اسم المادة";gravity=Gravity.RIGHT}
        AlertDialog.Builder(this).setTitle("إضافة مادة").setView(input).setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->
            val s=input.text.toString().trim(); if(s.isNotEmpty()){val set=(prefs.getStringSet("subjects",emptySet())?:emptySet()).toMutableSet();set.add(s);prefs.edit().putStringSet("subjects",set).apply();subjects()}
        }.show()
    }

    private fun studyPlan(){
        baseRoot();root.addView(title("خطة الدراسة"));root.addView(subtitle("خطتك اليومية بشكل بسيط وواضح."))
        val tasks=prefs.getStringSet("tasks", linkedSetOf("مراجعة الرياضيات","قراءة درس العلوم","مراجعة اللغة العربية"))?:emptySet()
        tasks.forEach{t->
            val row=CheckBox(this).apply{text=t;textSize=16f;setTextColor(if(dark)Color.WHITE else Color.DKGRAY);setPadding(8,10,8,10)}
            root.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,5)})
        }
        button("＋ إضافة مهمة"){addTask()};button("← الرئيسية"){showHome()};setContentView(scroll(root))
    }
    private fun addTask(){
        val input=EditText(this).apply{hint="مثال: حل 10 مسائل رياضيات";gravity=Gravity.RIGHT}
        AlertDialog.Builder(this).setTitle("مهمة جديدة").setView(input).setNegativeButton("إلغاء",null).setPositiveButton("إضافة"){_,_->val s=input.text.toString().trim();if(s.isNotEmpty()){val set=(prefs.getStringSet("tasks",emptySet())?:emptySet()).toMutableSet();set.add(s);prefs.edit().putStringSet("tasks",set).apply();studyPlan()}}.show()
    }

    private fun quiz(){
        baseRoot();root.addView(title("اختبر نفسك"));root.addView(subtitle("اختبار قصير للتدريب. اختر الإجابة الصحيحة."))
        val q=TextView(this).apply{text="ما ناتج 8 × 7 ؟";textSize=21f;setTypeface(null,Typeface.BOLD);setTextColor(if(dark)Color.WHITE else Color.rgb(20,40,70));setPadding(8,20,8,20)};root.addView(q)
        val group=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL};listOf("54","56","64","72").forEach{v->group.addView(RadioButton(this).apply{text=v;textSize=18f})};root.addView(group)
        button("تحقق من الإجابة"){val id=group.checkedRadioButtonId;if(id==-1)toast("اختر إجابة أولاً.") else {val selected=group.findViewById<RadioButton>(id).text.toString();toast(if(selected=="56")"أحسنت! إجابة صحيحة 🎉" else "ليست الإجابة الصحيحة. حاول مرة أخرى.")}}
        button("← الرئيسية"){showHome()};setContentView(scroll(root))
    }

    private fun search(){
        baseRoot();root.addView(title("البحث"));root.addView(subtitle("اكتب اسم الأداة التي تريد الوصول إليها."))
        val input=EditText(this).apply{hint="مثال: ملاحظاتي";gravity=Gravity.RIGHT};root.addView(input)
        val result=TextView(this).apply{textSize=17f;setTextColor(if(dark)Color.WHITE else Color.DKGRAY);setPadding(12,20,12,20)};root.addView(result)
        button("بحث"){val q=input.text.toString().trim();result.text=when{q.contains("ملاح")||q.contains("note",true)->"📝 ملاحظاتي";q.contains("خطة")||q.contains("جدول")->"📅 خطة الدراسة";q.contains("ماد")||q.contains("درس")->"📖 موادي الدراسية";q.contains("اخت")||q.contains("quiz",true)->"✅ اختبر نفسك";q.contains("تلخ")||q.contains("summary",true)->"📚 تلخيص الدروس";else->"لم نجد أداة مطابقة. جرّب كلمة أخرى."}}
        button("← الرئيسية"){showHome()};setContentView(scroll(root))
    }

    private fun settings(){
        baseRoot();root.addView(title("الإعدادات"));root.addView(subtitle("تحكم في تجربة التطبيق."))
        val toggle=Switch(this).apply{text="الوضع الليلي";textSize=17f;isChecked=dark;setTextColor(if(dark)Color.WHITE else Color.DKGRAY)};root.addView(toggle,LinearLayout.LayoutParams(-1,60));toggle.setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("dark",v).apply();dark=v;showHome()}
        button("معلومات التطبيق"){AlertDialog.Builder(this).setTitle("محمد AI Study").setMessage("مساعد دراسي عربي\nالإصدار 1.0\nإنتاج: محمد زهير\n\nنسخة أولى تعمل محليًا، وقابلة للتطوير وربط خدمات الذكاء الاصطناعي بشكل آمن.").setPositiveButton("حسنًا",null).show()}
        button("← الرئيسية"){showHome()};setContentView(scroll(root))
    }

    private fun openCamera(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),cameraRequest);return}
        try{startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))}catch(e:Exception){toast("لا يمكن فتح الكاميرا على هذا الجهاز.")}
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
